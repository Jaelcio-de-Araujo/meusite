<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/estilo.css"/>
  <meta charset="UTF-8"/>
  <link rel="icon" href="favicon.ico" type="image/ico" sizes="16x16">
  <title>Estudos de Php</title>
</head>
<body>
<div>
    <?php
        echo "Programando em Php 5.´6";
    ?>
</div>
</body>
</html>
 