<html>
<head>
<meta charset="utf-8"/>
<title>Contador de Clques em Php.</title>
</head>
<body>

<!-- Formulario de envio. -->

		<form method="POST" name="form01" action="contatdor.php">
		<input type="submit" value="Enviar">
		</form>
	
	<?php
		include("cont.txt");
		// Leitura do arquivo com numero 0 Incial.
		$file = fopen("cont.txt", "r");
		$contador = fread($file, filesize("cont.txt"));
		fclose($file);

		// Leitura do msmo Arquivo com incremento.
		$file = fopen("cont.txt", "r+");
		$contador++;
		fputs($file, $contador);
		fclose($file);
		echo (" Você obteve.");
	?>



</body>
</html>