<?php
//Script criador por Jaelcio de Araujo, para enviar e-mail.




$assunto		= "E-mail enviado do site.";
$email 			= "contato@contato.com.br";
$nome 			= "Jaelcio";
$SobreNome 		= "Araujo";
$idade 			= 27;
$msn   			= "Funcionando.";
?>

<?php

// O remetente deve ser um e-mail do seu domínio conforme determina a RFC 822.
// O return-path deve ser ser o mesmo e-mail do remetente.

$headers  =  "MIME-Version: 1.1\r\n";
$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
$headers .= "From: $email\r\n"; // remetente
$headers .= "Return-Path: $email\r\n"; // return-path
$envio 	  = mail("$email", "$assunto", "$msn", "$headers");
 
if($envio)
 echo "Mensagem enviada com sucesso";
else
 echo "A mensagem não pode ser enviada";
?>


